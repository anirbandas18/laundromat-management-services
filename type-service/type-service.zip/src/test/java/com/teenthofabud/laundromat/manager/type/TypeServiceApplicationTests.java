package com.teenthofabud.laundromat.manager.type;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TypeServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
