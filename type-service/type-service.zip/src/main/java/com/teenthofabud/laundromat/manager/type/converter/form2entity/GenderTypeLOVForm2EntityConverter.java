package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.GenderTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.GenderTypeLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class GenderTypeLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<GenderTypeLOVForm, GenderTypeLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public GenderTypeLOVEntity convert(GenderTypeLOVForm form) {
        GenderTypeLOVEntity entity = new GenderTypeLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
