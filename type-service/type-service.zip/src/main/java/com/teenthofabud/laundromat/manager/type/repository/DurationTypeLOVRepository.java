package com.teenthofabud.laundromat.manager.type.repository;

import com.teenthofabud.core.common.repository.TOABJpaRepository;
import com.teenthofabud.laundromat.manager.type.model.entity.DurationTypeLOVEntity;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

import javax.persistence.LockModeType;

@Repository
public interface DurationTypeLOVRepository extends TOABJpaRepository<DurationTypeLOVEntity> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    public DurationTypeLOVEntity save(DurationTypeLOVEntity entity);

}
