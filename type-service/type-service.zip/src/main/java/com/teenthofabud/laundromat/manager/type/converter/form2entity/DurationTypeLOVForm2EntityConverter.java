package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.DurationTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.DurationTypeLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class DurationTypeLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<DurationTypeLOVForm, DurationTypeLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public DurationTypeLOVEntity convert(DurationTypeLOVForm form) {
        DurationTypeLOVEntity entity = new DurationTypeLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
