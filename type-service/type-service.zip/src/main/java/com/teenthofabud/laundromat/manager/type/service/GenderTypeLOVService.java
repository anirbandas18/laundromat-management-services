package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.GenderTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.GenderTypeLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface GenderTypeLOVService {

    public void init();

    public Set<GenderTypeLOVVo> retrieveAllByNaturalOrdering();

    public GenderTypeLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<GenderTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createGenderTypeLOV(GenderTypeLOVForm form) throws TypeException;

    public void updateGenderTypeLOV(Long id, GenderTypeLOVForm form) throws TypeException;

    public void deleteGenderTypeLOV(Long id) throws TypeException;

    public void applyPatchOnGenderTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
