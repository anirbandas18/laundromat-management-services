package com.teenthofabud.laundromat.manager.type.controller;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.constants.LOVType;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.GenderTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.GenderTypeLOVVo;
import com.teenthofabud.laundromat.manager.type.service.GenderTypeLOVService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;


@RestController
@RequestMapping("gendertypelov")
public class GenderTypeLOVManagementController {

    @Autowired
    public void setService(GenderTypeLOVService service) {
        this.service = service;
    }

    private GenderTypeLOVService service;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Long> postNewGenderTypeLOV(@RequestBody(required = false) GenderTypeLOVForm form) throws TypeException {
        if(form != null) {
            long id = service.createGenderTypeLOV(form);
            return ResponseEntity.status(HttpStatus.CREATED).body(id);
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
    }

    @PutMapping(path = "{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> putExistingGenderTypeLOV(@PathVariable String id,
                                                           @RequestBody(required = false) GenderTypeLOVForm form) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(form != null) {
                    service.updateGenderTypeLOV(actualId, form);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteExistingGenderTypeLOV(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                service.deleteGenderTypeLOV(actualId);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @PatchMapping(path = "{id}", consumes = "application/json-patch+json")
    public ResponseEntity<Void> patchExistingGenderTypeLOV(@PathVariable String id,
                                                             @RequestBody(required = false) List<PatchOperationForm> dtoList) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(dtoList != null) {
                    service.applyPatchOnGenderTypeLOV(actualId, dtoList);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "patch", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @GetMapping
    public Set<GenderTypeLOVVo> getAllGenderTypeLOVNaturallyOrdered() {
        Set<GenderTypeLOVVo> naturallyOrderedStudents = service.retrieveAllByNaturalOrdering();
        return naturallyOrderedStudents;
    }

    @GetMapping("name/{name}")
    public List<GenderTypeLOVVo> getAllStudentsByName(@PathVariable String name) throws TypeException {
        if(StringUtils.hasText(name)) {
            List<GenderTypeLOVVo> matchedByNames = service.retrieveAllMatchingDetailsByName(name);
            return matchedByNames;
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "name", name });
    }

    @GetMapping("id/{id}")
    public GenderTypeLOVVo getGenderTypeLOVDetailsById(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                GenderTypeLOVVo studentDetails = service.retrieveDetailsById(actualId);
                return studentDetails;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

}
