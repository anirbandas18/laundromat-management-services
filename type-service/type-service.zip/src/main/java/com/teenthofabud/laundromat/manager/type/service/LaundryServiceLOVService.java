package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.LaundryServiceLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.LaundryServiceLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface LaundryServiceLOVService {

    public void init();

    public Set<LaundryServiceLOVVo> retrieveAllByNaturalOrdering();

    public LaundryServiceLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<LaundryServiceLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createLaundryServiceLOV(LaundryServiceLOVForm form) throws TypeException;

    public void updateLaundryServiceLOV(Long id, LaundryServiceLOVForm form) throws TypeException;

    public void deleteLaundryServiceLOV(Long id) throws TypeException;

    public void applyPatchOnLaundryServiceLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
