package com.teenthofabud.laundromat.manager.type.controller;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.constants.LOVType;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.LogisticServiceLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.LogisticServiceLOVVo;
import com.teenthofabud.laundromat.manager.type.service.LogisticServiceLOVService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;


@RestController
@RequestMapping("logisticservicelov")
public class LogisticServiceLOVManagementController {

    @Autowired
    public void setService(LogisticServiceLOVService service) {
        this.service = service;
    }

    private LogisticServiceLOVService service;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Long> postNewLogisticServiceLOV(@RequestBody(required = false) LogisticServiceLOVForm form) throws TypeException {
        if(form != null) {
            long id = service.createLogisticServiceLOV(form);
            return ResponseEntity.status(HttpStatus.CREATED).body(id);
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
    }

    @PutMapping(path = "{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> putExistingLogisticServiceLOV(@PathVariable String id,
                                                           @RequestBody(required = false) LogisticServiceLOVForm form) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(form != null) {
                    service.updateLogisticServiceLOV(actualId, form);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteExistingLogisticServiceLOV(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                service.deleteLogisticServiceLOV(actualId);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @PatchMapping(path = "{id}", consumes = "application/json-patch+json")
    public ResponseEntity<Void> patchExistingLogisticServiceLOV(@PathVariable String id,
                                                             @RequestBody(required = false) List<PatchOperationForm> dtoList) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(dtoList != null) {
                    service.applyPatchOnLogisticServiceLOV(actualId, dtoList);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "patch", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @GetMapping
    public Set<LogisticServiceLOVVo> getAllLogisticServiceLOVNaturallyOrdered() {
        Set<LogisticServiceLOVVo> naturallyOrderedStudents = service.retrieveAllByNaturalOrdering();
        return naturallyOrderedStudents;
    }

    @GetMapping("name/{name}")
    public List<LogisticServiceLOVVo> getAllStudentsByName(@PathVariable String name) throws TypeException {
        if(StringUtils.hasText(name)) {
            List<LogisticServiceLOVVo> matchedByNames = service.retrieveAllMatchingDetailsByName(name);
            return matchedByNames;
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "name", name });
    }

    @GetMapping("id/{id}")
    public LogisticServiceLOVVo getLogisticServiceLOVDetailsById(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                LogisticServiceLOVVo studentDetails = service.retrieveDetailsById(actualId);
                return studentDetails;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

}
