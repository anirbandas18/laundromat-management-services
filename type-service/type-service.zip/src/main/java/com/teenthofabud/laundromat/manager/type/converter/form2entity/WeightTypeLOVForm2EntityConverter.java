package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.WeightTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.WeightTypeLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class WeightTypeLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<WeightTypeLOVForm, WeightTypeLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public WeightTypeLOVEntity convert(WeightTypeLOVForm form) {
        WeightTypeLOVEntity entity = new WeightTypeLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
