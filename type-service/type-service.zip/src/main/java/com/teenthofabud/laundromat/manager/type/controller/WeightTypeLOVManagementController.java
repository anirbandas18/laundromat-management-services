package com.teenthofabud.laundromat.manager.type.controller;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.constants.LOVType;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.WeightTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.WeightTypeLOVVo;
import com.teenthofabud.laundromat.manager.type.service.WeightTypeLOVService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;


@RestController
@RequestMapping("weighttypelov")
public class WeightTypeLOVManagementController {

    @Autowired
    public void setService(WeightTypeLOVService service) {
        this.service = service;
    }

    private WeightTypeLOVService service;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Long> postNewWeightTypeLOV(@RequestBody(required = false) WeightTypeLOVForm form) throws TypeException {
        if(form != null) {
            long id = service.createWeightTypeLOV(form);
            return ResponseEntity.status(HttpStatus.CREATED).body(id);
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
    }

    @PutMapping(path = "{id}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> putExistingWeightTypeLOV(@PathVariable String id,
                                                           @RequestBody(required = false) WeightTypeLOVForm form) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(form != null) {
                    service.updateWeightTypeLOV(actualId, form);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteExistingWeightTypeLOV(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                service.deleteWeightTypeLOV(actualId);
                return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @PatchMapping(path = "{id}", consumes = "application/json-patch+json")
    public ResponseEntity<Void> patchExistingWeightTypeLOV(@PathVariable String id,
                                                             @RequestBody(required = false) List<PatchOperationForm> dtoList) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                if(dtoList != null) {
                    service.applyPatchOnWeightTypeLOV(actualId, dtoList);
                    return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
                }
                throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "patch", "not provided" });
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

    @GetMapping
    public Set<WeightTypeLOVVo> getAllWeightTypeLOVNaturallyOrdered() {
        Set<WeightTypeLOVVo> naturallyOrderedStudents = service.retrieveAllByNaturalOrdering();
        return naturallyOrderedStudents;
    }

    @GetMapping("name/{name}")
    public List<WeightTypeLOVVo> getAllStudentsByName(@PathVariable String name) throws TypeException {
        if(StringUtils.hasText(name)) {
            List<WeightTypeLOVVo> matchedByNames = service.retrieveAllMatchingDetailsByName(name);
            return matchedByNames;
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "name", name });
    }

    @GetMapping("id/{id}")
    public WeightTypeLOVVo getWeightTypeLOVDetailsById(@PathVariable String id) throws TypeException {
        if(StringUtils.hasText(id)) {
            try {
                long actualId = Long.parseLong(id);
                WeightTypeLOVVo studentDetails = service.retrieveDetailsById(actualId);
                return studentDetails;
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_INVALID, new Object[] { "id", id });
    }

}
