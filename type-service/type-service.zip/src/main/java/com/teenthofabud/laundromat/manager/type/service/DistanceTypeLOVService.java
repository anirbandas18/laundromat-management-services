package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.DistanceTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.DistanceTypeLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface DistanceTypeLOVService {

    public void init();

    public Set<DistanceTypeLOVVo> retrieveAllByNaturalOrdering();

    public DistanceTypeLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<DistanceTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createDistanceTypeLOV(DistanceTypeLOVForm form) throws TypeException;

    public void updateDistanceTypeLOV(Long id, DistanceTypeLOVForm form) throws TypeException;

    public void deleteDistanceTypeLOV(Long id) throws TypeException;

    public void applyPatchOnDistanceTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
