package com.teenthofabud.laundromat.manager.type.validator.dto;

import com.teenthofabud.laundromat.manager.type.model.dto.DurationTypeLOVDto;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.Optional;

@Component
public class DurationTypeLOVDtoValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(DurationTypeLOVDto.class);
    }

    @Override
    public void validate(Object target, Errors errors) {
        DurationTypeLOVDto dto = (DurationTypeLOVDto) target;

        Optional<String> optName = dto.getName();
        if((optName != null && optName.isPresent()) && StringUtils.isEmpty(optName.get())) {
            errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
            return;
        }
    }
}
