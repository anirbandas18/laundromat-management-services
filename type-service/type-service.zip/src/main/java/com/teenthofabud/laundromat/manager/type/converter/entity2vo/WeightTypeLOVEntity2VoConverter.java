package com.teenthofabud.laundromat.manager.type.converter.entity2vo;

import com.teenthofabud.laundromat.manager.type.model.entity.WeightTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.vo.WeightTypeLOVVo;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class WeightTypeLOVEntity2VoConverter implements Converter<WeightTypeLOVEntity, WeightTypeLOVVo> {
    @Override
    public WeightTypeLOVVo convert(WeightTypeLOVEntity entity) {
        WeightTypeLOVVo vo = new WeightTypeLOVVo();
        vo.setName(entity.getName());
        vo.setDescription(entity.getDescription());
        vo.setId(entity.getId());
        vo.setActive(entity.getActive());
        return vo;
    }
}
