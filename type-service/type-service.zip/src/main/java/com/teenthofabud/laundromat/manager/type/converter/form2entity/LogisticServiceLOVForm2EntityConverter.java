package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.LogisticServiceLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.LogisticServiceLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class LogisticServiceLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<LogisticServiceLOVForm, LogisticServiceLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public LogisticServiceLOVEntity convert(LogisticServiceLOVForm form) {
        LogisticServiceLOVEntity entity = new LogisticServiceLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
