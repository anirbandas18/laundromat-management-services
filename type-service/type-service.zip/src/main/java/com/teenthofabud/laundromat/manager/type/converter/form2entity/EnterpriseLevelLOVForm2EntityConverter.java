package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.EnterpriseLevelLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.EnterpriseLevelLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class EnterpriseLevelLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<EnterpriseLevelLOVForm, EnterpriseLevelLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public EnterpriseLevelLOVEntity convert(EnterpriseLevelLOVForm form) {
        EnterpriseLevelLOVEntity entity = new EnterpriseLevelLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
