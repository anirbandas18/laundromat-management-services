package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.DurationTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.DurationTypeLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface DurationTypeLOVService {

    public void init();

    public Set<DurationTypeLOVVo> retrieveAllByNaturalOrdering();

    public DurationTypeLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<DurationTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createDurationTypeLOV(DurationTypeLOVForm form) throws TypeException;

    public void updateDurationTypeLOV(Long id, DurationTypeLOVForm form) throws TypeException;

    public void deleteDurationTypeLOV(Long id) throws TypeException;

    public void applyPatchOnDurationTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
