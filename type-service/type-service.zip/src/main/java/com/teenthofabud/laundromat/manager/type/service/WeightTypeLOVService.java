package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.WeightTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.WeightTypeLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface WeightTypeLOVService {

    public void init();

    public Set<WeightTypeLOVVo> retrieveAllByNaturalOrdering();

    public WeightTypeLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<WeightTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createWeightTypeLOV(WeightTypeLOVForm form) throws TypeException;

    public void updateWeightTypeLOV(Long id, WeightTypeLOVForm form) throws TypeException;

    public void deleteWeightTypeLOV(Long id) throws TypeException;

    public void applyPatchOnWeightTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
