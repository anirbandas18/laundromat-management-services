package com.teenthofabud.laundromat.manager.type.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;
import com.teenthofabud.core.common.converter.ComparativeFormConverter;
import com.teenthofabud.core.common.converter.ComparativePatchConverter;
import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.core.common.validator.PatchOperationFormValidator;
import com.teenthofabud.core.common.validator.RelaxedValidator;
import com.teenthofabud.laundromat.manager.type.converter.entity2vo.WeightTypeLOVEntity2VoConverter;
import com.teenthofabud.laundromat.manager.type.converter.form2entity.WeightTypeLOVForm2EntityConverter;
import com.teenthofabud.laundromat.manager.type.model.constants.LOVType;
import com.teenthofabud.laundromat.manager.type.model.dto.WeightTypeLOVDto;
import com.teenthofabud.laundromat.manager.type.model.entity.WeightTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.WeightTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.WeightTypeLOVVo;
import com.teenthofabud.laundromat.manager.type.repository.WeightTypeLOVRepository;
import com.teenthofabud.laundromat.manager.type.service.WeightTypeLOVService;
import com.teenthofabud.laundromat.manager.type.validator.dto.WeightTypeLOVDtoValidator;
import com.teenthofabud.laundromat.manager.type.validator.form.WeightTypeLOVFormValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.Errors;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

@Component
@Slf4j
public class WeightTypeLOVServiceImpl implements WeightTypeLOVService {

    private static final Comparator<WeightTypeLOVVo> CMP_BY_NAME = (s1, s2) -> {
        return s1.getName().compareTo(s2.getName());
    };

    private WeightTypeLOVEntity2VoConverter entity2VoConverter;
    private WeightTypeLOVForm2EntityConverter form2EntityConverter;
    private WeightTypeLOVFormValidator formValidator;
    private WeightTypeLOVDtoValidator dtoValidator;
    private WeightTypeLOVRepository repository;
    private PatchOperationFormValidator patchOperationValidator;
    private ObjectMapper om;

    @Autowired
    public void setPatchOperationValidator(PatchOperationFormValidator patchOperationValidator) {
        this.patchOperationValidator = patchOperationValidator;
    }

    @Autowired
    public void setOm(ObjectMapper om) {
        this.om = om;
    }

    @Autowired
    public void setDtoValidator(WeightTypeLOVDtoValidator dtoValidator) {
        this.dtoValidator = dtoValidator;
    }

    @Autowired
    public void setEntity2VOConverter(WeightTypeLOVEntity2VoConverter entity2VoConverter) {
        this.entity2VoConverter = entity2VoConverter;
    }

    @Autowired
    public void setForm2EntityConverter(WeightTypeLOVForm2EntityConverter form2EntityConverter) {
        this.form2EntityConverter = form2EntityConverter;
    }

    @Autowired
    public void setRepository(WeightTypeLOVRepository repository) {
        this.repository = repository;
    }

    @Autowired
    public void setFormValidator(WeightTypeLOVFormValidator formValidator) {
        this.formValidator = formValidator;
    }

    private RelaxedValidator<WeightTypeLOVForm> LOOSE_STUDENT_VALIDATOR;
    private ComparativePatchConverter<WeightTypeLOVEntity, WeightTypeLOVDto> COMPARE_AND_COPY_PATCH;
    private ComparativeFormConverter<WeightTypeLOVEntity, WeightTypeLOVEntity> COMPARE_AND_COPY_ENTITY;
    private ComparativeFormConverter<WeightTypeLOVEntity, WeightTypeLOVForm> COMPARE_AND_COPY_FORM;

    @Override
    @PostConstruct
    public void init() {
        LOOSE_STUDENT_VALIDATOR = (form, errors) -> {
            if(form.getName() != null && form.getName().length() == 0) {
                errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
                return false;
            }
            return true;
        };

        COMPARE_AND_COPY_PATCH = (actualEntity, form) -> {
            boolean changeSW = false;
            if(form.getDescription().isPresent()) {
                actualEntity.setDescription(form.getDescription().get());
                changeSW = true;
            }
            if(form.getName().isPresent()) {
                actualEntity.setName(form.getName().get());
                changeSW = true;
            }
            if(changeSW) {
                actualEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
            }
        };

        COMPARE_AND_COPY_ENTITY = (source, target) -> {
            WeightTypeLOVEntity expectedEntity = new WeightTypeLOVEntity();
            boolean changeSW = false;
            if(source.getId() != null && source.getId() > 0 && source.getId().compareTo(target.getId()) != 0) {
                target.setId(source.getId());
                changeSW = true;
            }
            if(source.getDescription() != null && source.getDescription().compareTo(target.getDescription()) != 0) {
                target.setDescription(source.getDescription());
                changeSW = true;
            }
            if(source.getName() != null && StringUtils.hasText(source.getName()) && source.getName().compareTo(target.getName()) != 0) {
                target.setName(source.getName());
                changeSW = true;
            }
            return changeSW ? Optional.of(target) : Optional.empty();
        };

        COMPARE_AND_COPY_FORM = (actualEntity, form) -> {
            WeightTypeLOVEntity expectedEntity = new WeightTypeLOVEntity();
            boolean changeSW = false;
            // direct copy
            expectedEntity.setId(actualEntity.getId());
            expectedEntity.setCreatedOn(actualEntity.getCreatedOn());
            expectedEntity.setActive(actualEntity.getActive());
            // comparative copy
            if(StringUtils.hasText(form.getName()) && form.getName().compareTo(actualEntity.getName()) != 0) {
                expectedEntity.setName(form.getName());
                changeSW = true;
            } else {
                expectedEntity.setName(actualEntity.getName());
                changeSW = true;
            }
            if(StringUtils.hasText(form.getDescription()) &&
                    form.getDescription().toLowerCase().compareTo(actualEntity.getDescription().toLowerCase()) != 0) {
                expectedEntity.setDescription(form.getDescription());
                changeSW = true;
            } else {
                expectedEntity.setDescription(actualEntity.getDescription());
                changeSW = true;
            }
            return changeSW ? Optional.of(expectedEntity) : Optional.empty();
        };
    }

    private List<WeightTypeLOVVo> entity2DetailedVoList(List<WeightTypeLOVEntity> studentEntityList) {
        List<WeightTypeLOVVo> studentDetailsList = new ArrayList<>(studentEntityList.size());
        for(WeightTypeLOVEntity entity : studentEntityList) {
            WeightTypeLOVVo vo = entity2VoConverter.convert(entity);
            studentDetailsList.add(vo);
        }
        return studentDetailsList;
    }

    @Override
    @Transactional(readOnly = true)
    public Set<WeightTypeLOVVo> retrieveAllByNaturalOrdering() {
        List<WeightTypeLOVEntity> studentEntityList = repository.findAll();
        Set<WeightTypeLOVVo> naturallyOrderedSet = new TreeSet<WeightTypeLOVVo>();
        for(WeightTypeLOVEntity entity : studentEntityList) {
            WeightTypeLOVVo dto = entity2VoConverter.convert(entity);
            naturallyOrderedSet.add(dto);
        }
        return naturallyOrderedSet;
    }

    @Override
    @Transactional(readOnly = true)
    public WeightTypeLOVVo retrieveDetailsById(long id) throws TypeException {
        Optional<WeightTypeLOVEntity> optEntity = repository.findById(id);
        if(optEntity.isEmpty()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        WeightTypeLOVEntity entity = optEntity.get();
        if(!entity.getActive()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        WeightTypeLOVVo vo = entity2VoConverter.convert(entity);
        return vo;
    }



    @Override
    @Transactional(readOnly = true)
    public List<WeightTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException {
        List<WeightTypeLOVEntity> studentEntityList = repository.findByNameContaining(name);
        if(studentEntityList != null && !studentEntityList.isEmpty()) {
            List<WeightTypeLOVVo> matchedWeightTypeLOVDetailsList = entity2DetailedVoList(studentEntityList);
            return matchedWeightTypeLOVDetailsList;
        }
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "name", name });
    }

    @Override
    @Transactional
    public Long createWeightTypeLOV(WeightTypeLOVForm form) throws TypeException {
        if(form == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
        }
        Errors err = new DirectFieldBindingResult(form, form.getClass().getSimpleName());
        formValidator.validate(form, err);
        if(err.hasErrors()) {
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        }
        WeightTypeLOVEntity expectedEntity = form2EntityConverter.convert(form);
        if(repository.existsByName(expectedEntity.getName())) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_EXISTS,
                    new Object[]{ "name", form.getName() });
        }
        WeightTypeLOVEntity actualEntity = repository.save(expectedEntity);
        if(actualEntity == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "creation", "unable to persist currency type LOV details" });
        }
        return actualEntity.getId();
    }

    @Override
    @Transactional
    public void updateWeightTypeLOV(Long id, WeightTypeLOVForm form) throws TypeException {
        Optional<WeightTypeLOVEntity> optActualEntity = repository.findById(id);
        if(optActualEntity.isEmpty()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }

        WeightTypeLOVEntity actualEntity = optActualEntity.get();
        if(!actualEntity.getActive()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }

        if(form == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
        }

        Errors err = new DirectFieldBindingResult(form, form.getClass().getSimpleName());
        Boolean allEmpty = LOOSE_STUDENT_VALIDATOR.validateLoosely(form, err);
        if(err.hasErrors()) {
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        } else if (allEmpty) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "fields are empty" });
        }

        Optional<WeightTypeLOVEntity> optExpectedEntity = COMPARE_AND_COPY_FORM.compareAndMap(actualEntity, form);
        if(optExpectedEntity.isEmpty()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "fields are empty" });
        }

        WeightTypeLOVEntity expectedEntity = optExpectedEntity.get();

        if(repository.existsByName(expectedEntity.getName())) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_EXISTS,
                    new Object[]{ "name", actualEntity.getName(), "major" });
        }

        COMPARE_AND_COPY_ENTITY.compareAndMap(expectedEntity, actualEntity);

        expectedEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
        actualEntity = repository.save(actualEntity);
        if(actualEntity == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "update", "unable to persist currency type LOV details" });
        }
    }

    @Override
    @Transactional
    public void deleteWeightTypeLOV(Long id) throws TypeException {
        Optional<WeightTypeLOVEntity> optEntity = repository.findById(id);
        if(optEntity.isEmpty()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        WeightTypeLOVEntity expectedEntity = optEntity.get();
        if(!expectedEntity.getActive()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        expectedEntity.setActive(Boolean.FALSE);
        expectedEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
        WeightTypeLOVEntity actualEntity = repository.save(expectedEntity);
        if(actualEntity == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "deletion", "unable to soft delete currenct type LOV details with id:" + id });
        }
    }

    @Override
    @Transactional
    public void applyPatchOnWeightTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException {
        Optional<WeightTypeLOVEntity> optActualEntity = repository.findById(id);
        if(optActualEntity.isEmpty()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        WeightTypeLOVEntity actualEntity = optActualEntity.get();
        if(!actualEntity.getActive()) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        if(patches == null || (patches != null && patches.isEmpty())) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "patch", "not provided" });
        }
        for(PatchOperationForm pof : patches) {
            Errors err = new DirectFieldBindingResult(pof, pof.getClass().getSimpleName());
            patchOperationValidator.validate(pof, err);
            if(err.hasErrors()) {
                TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
                throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
            }
        }
        WeightTypeLOVDto patchedWeightTypeLOVForm = new WeightTypeLOVDto();
        try {
            JsonNode studentDtoTree = om.convertValue(patches, JsonNode.class);
            JsonPatch studentPatch = JsonPatch.fromJson(studentDtoTree);
            JsonNode blankWeightTypeLOVDtoTree = om.convertValue(new WeightTypeLOVDto(), JsonNode.class);
            JsonNode patchedWeightTypeLOVFormTree = studentPatch.apply(blankWeightTypeLOVDtoTree);
            patchedWeightTypeLOVForm = om.treeToValue(patchedWeightTypeLOVFormTree, WeightTypeLOVDto.class);
        } catch (IOException | JsonPatchException e) {
            e.printStackTrace();
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE, new Object[]{ "patching", "internal error: " + e.getMessage() });
        }
        Errors err = new DirectFieldBindingResult(patchedWeightTypeLOVForm, patchedWeightTypeLOVForm.getClass().getSimpleName());
        dtoValidator.validate(patchedWeightTypeLOVForm, err);
        if(err.hasErrors()) {
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        }
        COMPARE_AND_COPY_PATCH.compareAndMap(actualEntity, patchedWeightTypeLOVForm);
        actualEntity = repository.save(actualEntity);
        if(actualEntity == null) {
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "patching", "unable to patch currency type LOV details with id:" + id });
        }
    }
}