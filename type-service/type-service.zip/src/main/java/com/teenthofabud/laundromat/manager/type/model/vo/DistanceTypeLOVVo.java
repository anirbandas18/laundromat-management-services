package com.teenthofabud.laundromat.manager.type.model.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DistanceTypeLOVVo implements Comparable<DistanceTypeLOVVo> {

    private Long id;
    private Boolean active;
    private String name;
    private String description;

    @Override
    public int compareTo(DistanceTypeLOVVo o) {
        return Long.compare(this.id, o.getId());
    }

}
