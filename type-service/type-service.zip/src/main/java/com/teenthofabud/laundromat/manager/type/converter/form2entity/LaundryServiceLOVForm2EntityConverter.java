package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.LaundryServiceLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.LaundryServiceLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class LaundryServiceLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<LaundryServiceLOVForm, LaundryServiceLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public LaundryServiceLOVEntity convert(LaundryServiceLOVForm form) {
        LaundryServiceLOVEntity entity = new LaundryServiceLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
