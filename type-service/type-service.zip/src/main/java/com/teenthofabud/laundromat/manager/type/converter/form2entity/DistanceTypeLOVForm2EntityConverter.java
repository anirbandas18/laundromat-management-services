package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.DistanceTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.DistanceTypeLOVForm;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class DistanceTypeLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<DistanceTypeLOVForm, DistanceTypeLOVEntity> {

    private static final Long DEFAULT_USER_ID = 1L;

    @Override
    public DistanceTypeLOVEntity convert(DistanceTypeLOVForm form) {
        DistanceTypeLOVEntity entity = new DistanceTypeLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        return entity;
    }
}
