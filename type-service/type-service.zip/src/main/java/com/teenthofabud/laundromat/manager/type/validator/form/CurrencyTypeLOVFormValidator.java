package com.teenthofabud.laundromat.manager.type.validator.form;

import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.form.CurrencyTypeLOVForm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
@Slf4j
public class CurrencyTypeLOVFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(CurrencyTypeLOVForm.class);
    }

    @Override
    public void validate(Object target, Errors errors) {
        CurrencyTypeLOVForm form = (CurrencyTypeLOVForm) target;
        if(StringUtils.isEmpty(form.getName())) {
            log.debug("CurrencyTypeLOVForm.name is empty");
            errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
            return;
        }
    }
}
