package com.teenthofabud.laundromat.manager.type.converter.entity2vo;

import com.teenthofabud.laundromat.manager.type.model.entity.DurationTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.vo.DurationTypeLOVVo;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class DurationTypeLOVEntity2VoConverter implements Converter<DurationTypeLOVEntity, DurationTypeLOVVo> {
    @Override
    public DurationTypeLOVVo convert(DurationTypeLOVEntity entity) {
        DurationTypeLOVVo vo = new DurationTypeLOVVo();
        vo.setName(entity.getName());
        vo.setDescription(entity.getDescription());
        vo.setId(entity.getId());
        vo.setActive(entity.getActive());
        return vo;
    }
}
