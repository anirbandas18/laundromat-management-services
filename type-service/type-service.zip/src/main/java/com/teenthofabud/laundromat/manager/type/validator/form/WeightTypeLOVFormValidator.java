package com.teenthofabud.laundromat.manager.type.validator.form;

import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.form.WeightTypeLOVForm;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class WeightTypeLOVFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(WeightTypeLOVForm.class);
    }

    @Override
    public void validate(Object target, Errors errors) {
        WeightTypeLOVForm form = (WeightTypeLOVForm) target;
        if(StringUtils.isEmpty(form.getName())) {
            errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
            return;
        }
    }
}
