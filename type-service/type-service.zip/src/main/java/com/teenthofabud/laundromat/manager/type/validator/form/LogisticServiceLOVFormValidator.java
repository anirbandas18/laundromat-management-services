package com.teenthofabud.laundromat.manager.type.validator.form;

import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.form.LogisticServiceLOVForm;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class LogisticServiceLOVFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(LogisticServiceLOVForm.class);
    }

    @Override
    public void validate(Object target, Errors errors) {
        LogisticServiceLOVForm form = (LogisticServiceLOVForm) target;
        if(StringUtils.isEmpty(form.getName())) {
            errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
            return;
        }
    }
}
