package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.CurrencyTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.CurrencyTypeLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface CurrencyTypeLOVService {

    public void init();

    public Set<CurrencyTypeLOVVo> retrieveAllByNaturalOrdering();

    public CurrencyTypeLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<CurrencyTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createCurrencyTypeLOV(CurrencyTypeLOVForm form) throws TypeException;

    public void updateCurrencyTypeLOV(Long id, CurrencyTypeLOVForm form) throws TypeException;

    public void deleteCurrencyTypeLOV(Long id) throws TypeException;

    public void applyPatchOnCurrencyTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
