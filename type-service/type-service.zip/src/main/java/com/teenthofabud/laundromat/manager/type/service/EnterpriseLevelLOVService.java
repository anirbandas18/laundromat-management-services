package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.EnterpriseLevelLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.EnterpriseLevelLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface EnterpriseLevelLOVService {

    public void init();

    public Set<EnterpriseLevelLOVVo> retrieveAllByNaturalOrdering();

    public EnterpriseLevelLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<EnterpriseLevelLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createEnterpriseLevelLOV(EnterpriseLevelLOVForm form) throws TypeException;

    public void updateEnterpriseLevelLOV(Long id, EnterpriseLevelLOVForm form) throws TypeException;

    public void deleteEnterpriseLevelLOV(Long id) throws TypeException;

    public void applyPatchOnEnterpriseLevelLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
