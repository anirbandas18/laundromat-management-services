package com.teenthofabud.laundromat.manager.type.service;

import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.LogisticServiceLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.LogisticServiceLOVVo;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface LogisticServiceLOVService {

    public void init();

    public Set<LogisticServiceLOVVo> retrieveAllByNaturalOrdering();

    public LogisticServiceLOVVo retrieveDetailsById(long id) throws TypeException;

    public List<LogisticServiceLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException;

    public Long createLogisticServiceLOV(LogisticServiceLOVForm form) throws TypeException;

    public void updateLogisticServiceLOV(Long id, LogisticServiceLOVForm form) throws TypeException;

    public void deleteLogisticServiceLOV(Long id) throws TypeException;

    public void applyPatchOnLogisticServiceLOV(Long id, List<PatchOperationForm> patches) throws TypeException;



}
