package com.teenthofabud.laundromat.manager.type.validator.form;

import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.form.GenderTypeLOVForm;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class GenderTypeLOVFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.isAssignableFrom(GenderTypeLOVForm.class);
    }

    @Override
    public void validate(Object target, Errors errors) {
        GenderTypeLOVForm form = (GenderTypeLOVForm) target;
        if(StringUtils.isEmpty(form.getName())) {
            errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
            return;
        }
    }
}
