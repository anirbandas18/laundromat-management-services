package com.teenthofabud.laundromat.manager.type.converter.form2entity;

import com.teenthofabud.core.common.handler.TOABBaseEntityConversionHandler;
import com.teenthofabud.laundromat.manager.type.model.entity.CurrencyTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.form.CurrencyTypeLOVForm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CurrencyTypeLOVForm2EntityConverter extends TOABBaseEntityConversionHandler implements Converter<CurrencyTypeLOVForm, CurrencyTypeLOVEntity> {

    @Override
    public CurrencyTypeLOVEntity convert(CurrencyTypeLOVForm form) {
        CurrencyTypeLOVEntity entity = new CurrencyTypeLOVEntity();
        entity.setName(form.getName());
        entity.setDescription(form.getDescription());
        super.assignAuditValues(entity, Boolean.TRUE);
        log.debug("Converting {} to {}", form, entity);
        return entity;
    }
}
