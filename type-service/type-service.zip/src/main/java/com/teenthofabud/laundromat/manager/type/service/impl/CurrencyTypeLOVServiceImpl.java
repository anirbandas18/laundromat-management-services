package com.teenthofabud.laundromat.manager.type.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonpatch.JsonPatch;
import com.github.fge.jsonpatch.JsonPatchException;
import com.teenthofabud.core.common.converter.ComparativeFormConverter;
import com.teenthofabud.core.common.converter.ComparativePatchConverter;
import com.teenthofabud.core.common.model.error.TOABBaseException;
import com.teenthofabud.core.common.model.form.PatchOperationForm;
import com.teenthofabud.core.common.service.TOABBaseService;
import com.teenthofabud.core.common.validator.RelaxedValidator;
import com.teenthofabud.laundromat.manager.type.converter.entity2vo.CurrencyTypeLOVEntity2VoConverter;
import com.teenthofabud.laundromat.manager.type.converter.form2entity.CurrencyTypeLOVForm2EntityConverter;
import com.teenthofabud.laundromat.manager.type.model.constants.LOVType;
import com.teenthofabud.laundromat.manager.type.model.dto.CurrencyTypeLOVDto;
import com.teenthofabud.laundromat.manager.type.model.entity.CurrencyTypeLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.error.TypeErrorCode;
import com.teenthofabud.laundromat.manager.type.model.error.TypeException;
import com.teenthofabud.laundromat.manager.type.model.form.CurrencyTypeLOVForm;
import com.teenthofabud.laundromat.manager.type.model.vo.CurrencyTypeLOVVo;
import com.teenthofabud.laundromat.manager.type.repository.CurrencyTypeLOVRepository;
import com.teenthofabud.laundromat.manager.type.service.CurrencyTypeLOVService;
import com.teenthofabud.laundromat.manager.type.validator.dto.CurrencyTypeLOVDtoValidator;
import com.teenthofabud.laundromat.manager.type.validator.form.CurrencyTypeLOVFormValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.validation.DirectFieldBindingResult;
import org.springframework.validation.Errors;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

@Component
@Slf4j
public class CurrencyTypeLOVServiceImpl implements CurrencyTypeLOVService {

    private static final Comparator<CurrencyTypeLOVVo> CMP_BY_NAME = (s1, s2) -> {
        return s1.getName().compareTo(s2.getName());
    };

    private static RelaxedValidator<CurrencyTypeLOVForm> LOOSE_CURRENCY_TYPE_VALIDATOR;
    private static ComparativePatchConverter<CurrencyTypeLOVEntity, CurrencyTypeLOVDto> COMPARE_AND_COPY_PATCH;
    private static ComparativeFormConverter<CurrencyTypeLOVEntity, CurrencyTypeLOVEntity> COMPARE_AND_COPY_ENTITY;
    private static ComparativeFormConverter<CurrencyTypeLOVEntity, CurrencyTypeLOVForm> COMPARE_AND_COPY_FORM;

    private CurrencyTypeLOVEntity2VoConverter entity2VoConverter;
    private CurrencyTypeLOVForm2EntityConverter form2EntityConverter;
    private CurrencyTypeLOVFormValidator formValidator;
    private CurrencyTypeLOVDtoValidator dtoValidator;
    private CurrencyTypeLOVRepository repository;
    private TOABBaseService toabBaseService;
    private ObjectMapper om;

    @Autowired
    public void setPatchOperationValidator(TOABBaseService toabBaseService) {
        this.toabBaseService = toabBaseService;
    }

    @Autowired
    public void setOm(ObjectMapper om) {
        this.om = om;
    }

    @Autowired
    public void setDtoValidator(CurrencyTypeLOVDtoValidator dtoValidator) {
        this.dtoValidator = dtoValidator;
    }

    @Autowired
    public void setEntity2VOConverter(CurrencyTypeLOVEntity2VoConverter entity2VoConverter) {
        this.entity2VoConverter = entity2VoConverter;
    }

    @Autowired
    public void setForm2EntityConverter(CurrencyTypeLOVForm2EntityConverter form2EntityConverter) {
        this.form2EntityConverter = form2EntityConverter;
    }

    @Autowired
    public void setRepository(CurrencyTypeLOVRepository repository) {
        this.repository = repository;
    }

    @Autowired
    public void setFormValidator(CurrencyTypeLOVFormValidator formValidator) {
        this.formValidator = formValidator;
    }

    @Override
    @PostConstruct
    public void init() {
        LOOSE_CURRENCY_TYPE_VALIDATOR = (form, errors) -> {
            if(form.getName() != null && form.getName().length() == 0) {
                errors.rejectValue("name", TypeErrorCode.METADATA_ATTRIBUTE_INVALID.name());
                log.debug("CurrencyTypeLOVForm.name is empty");
                return false;
            }
            log.debug("CurrencyTypeLOVForm.name is valid");
            return true;
        };

        COMPARE_AND_COPY_PATCH = (actualEntity, form) -> {
            boolean changeSW = false;
            if(form.getDescription().isPresent()) {
                actualEntity.setDescription(form.getDescription().get());
                changeSW = true;
                log.debug("CurrencyTypeLOVDto.description is valid");
            }
            if(form.getName().isPresent()) {
                actualEntity.setName(form.getName().get());
                changeSW = true;
                log.debug("CurrencyTypeLOVDto.name is valid");
            }
            if(form.getActive().isPresent()) {
                actualEntity.setActive(Boolean.valueOf(form.getActive().get()));
                changeSW = true;
                log.debug("CurrencyTypeLOVDto.active is valid");
            }
            if(changeSW) {
                log.debug("All provided CurrencyTypeLOVDto attributes are valid");
                actualEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
                return;
            }
            log.debug("Not all provided CurrencyTypeLOVDto attributes are valid");
        };

        COMPARE_AND_COPY_ENTITY = (source, target) -> {
            CurrencyTypeLOVEntity expectedEntity = new CurrencyTypeLOVEntity();
            boolean changeSW = false;
            if(source.getId() != null && source.getId() > 0 && source.getId().compareTo(target.getId()) != 0) {
                target.setId(source.getId());
                changeSW = true;
                log.debug("Source CurrencyTypeLOVEntity.id is valid");
            }
            if(source.getDescription() != null && source.getDescription().compareTo(target.getDescription()) != 0) {
                target.setDescription(source.getDescription());
                changeSW = true;
                log.debug("Source CurrencyTypeLOVEntity.description is valid");
            }
            if(source.getName() != null && StringUtils.hasText(source.getName()) && source.getName().compareTo(target.getName()) != 0) {
                target.setName(source.getName());
                changeSW = true;
                log.debug("Source CurrencyTypeLOVEntity.name is valid");
            }
            if(changeSW) {
                log.debug("All provided CurrencyTypeLOVEntity attributes are valid");
                return Optional.of(target);
            } else {
                log.debug("Not all provided CurrencyTypeLOVEntity attributes are valid");
                return Optional.empty();
            }
        };

        COMPARE_AND_COPY_FORM = (actualEntity, form) -> {
            CurrencyTypeLOVEntity expectedEntity = new CurrencyTypeLOVEntity();
            boolean changeSW = false;
            // direct copy
            expectedEntity.setId(actualEntity.getId());
            log.debug("Directly copying CurrencyTypeLOVEntity.id: {} from actualEntity to expectedEntity", actualEntity.getId());
            expectedEntity.setCreatedOn(actualEntity.getCreatedOn());
            log.debug("Directly copying CurrencyTypeLOVEntity.createdOn: {} from actualEntity to expectedEntity", actualEntity.getCreatedOn());
            expectedEntity.setActive(actualEntity.getActive());
            log.debug("Directly copying CurrencyTypeLOVEntity.active: {} from actualEntity to expectedEntity", actualEntity.getActive());
            // comparative copy
            if(StringUtils.hasText(form.getName()) && form.getName().compareTo(actualEntity.getName()) != 0) {
                expectedEntity.setName(form.getName());
                changeSW = true;
                log.debug("CurrencyTypeLOVForm.name: {} is same as CurrencyTypeLOVEntity.name: {}", form.getName(), actualEntity.getName());
            } else {
                expectedEntity.setName(actualEntity.getName());
                changeSW = true;
                log.debug("CurrencyTypeLOVForm.name: {} is different to CurrencyTypeLOVEntity.name: {}", form.getName(), actualEntity.getName());
            }
            if(StringUtils.hasText(form.getDescription()) &&
                    form.getDescription().toLowerCase().compareTo(actualEntity.getDescription().toLowerCase()) != 0) {
                expectedEntity.setDescription(form.getDescription());
                changeSW = true;
                log.debug("CurrencyTypeLOVForm.description: {} is same as CurrencyTypeLOVEntity.description: {}", form.getDescription(), actualEntity.getDescription());
            } else {
                expectedEntity.setDescription(actualEntity.getDescription());
                changeSW = true;
                log.debug("CurrencyTypeLOVForm.description: {} is different to CurrencyTypeLOVEntity.description: {}", form.getDescription(), actualEntity.getDescription());
            }
            return changeSW ? Optional.of(expectedEntity) : Optional.empty();
        };
        log.debug("Initialized bean with pre-requisites");
    }

    private List<CurrencyTypeLOVVo> entity2DetailedVoList(List<CurrencyTypeLOVEntity> studentEntityList) {
        List<CurrencyTypeLOVVo> studentDetailsList = new ArrayList<>(studentEntityList.size());
        for(CurrencyTypeLOVEntity entity : studentEntityList) {
            CurrencyTypeLOVVo vo = entity2VoConverter.convert(entity);
            log.debug("Converting {} to {}", entity, vo);
            studentDetailsList.add(vo);
        }
        return studentDetailsList;
    }

    @Override
    @Transactional(readOnly = true)
    public Set<CurrencyTypeLOVVo> retrieveAllByNaturalOrdering() {
        log.info("Requesting all CurrencyTypeLOVEntity by their natural ordering");
        List<CurrencyTypeLOVEntity> studentEntityList = repository.findAll();
        Set<CurrencyTypeLOVVo> naturallyOrderedSet = new TreeSet<CurrencyTypeLOVVo>();
        for(CurrencyTypeLOVEntity entity : studentEntityList) {
            CurrencyTypeLOVVo dto = entity2VoConverter.convert(entity);
            log.debug("Converting {} to {}", entity, dto);
            naturallyOrderedSet.add(dto);
        }
        log.info("{} CurrencyTypeLOVVo available", naturallyOrderedSet.size());
        return naturallyOrderedSet;
    }

    @Override
    @Transactional(readOnly = true)
    public CurrencyTypeLOVVo retrieveDetailsById(long id) throws TypeException {
        log.info("Requesting CurrencyTypeLOVEntity by id: {}", id);
        Optional<CurrencyTypeLOVEntity> optEntity = repository.findById(id);
        if(optEntity.isEmpty()) {
            log.debug("No CurrencyTypeLOVEntity found by id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        CurrencyTypeLOVEntity entity = optEntity.get();
        if(!entity.getActive()) {
            log.debug("CurrencyTypeLOVEntity is inactive by id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        CurrencyTypeLOVVo vo = entity2VoConverter.convert(entity);
        log.info("Found CurrencyTypeLOVVo by id: {}", id);
        return vo;
    }


    @Override
    @Transactional(readOnly = true)
    public List<CurrencyTypeLOVVo> retrieveAllMatchingDetailsByName(String name) throws TypeException {
        log.info("Requesting CurrencyTypeLOVEntity that match with name: {}", name);
        List<CurrencyTypeLOVEntity> studentEntityList = repository.findByNameContaining(name);
        if(studentEntityList != null && !studentEntityList.isEmpty()) {
            List<CurrencyTypeLOVVo> matchedCurrencyTypeLOVList = entity2DetailedVoList(studentEntityList);
            log.info("Found {} CurrencyTypeLOVVo matching with name: {}", matchedCurrencyTypeLOVList.size(),name);
            return matchedCurrencyTypeLOVList;
        }
        log.debug("No CurrencyTypeLOVVo found matching with name: {}", name);
        throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "name", name });
    }

    @Override
    @Transactional
    public Long createCurrencyTypeLOV(CurrencyTypeLOVForm form) throws TypeException {
        log.info("Creating new CurrencyTypeLOVEntity");

        if(form == null) {
            log.debug("CurrencyTypeLOVForm provided is null");
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
        }
        log.debug("Form details: {}", form);

        log.debug("Validating provided attributes of CurrencyTypeLOVForm");
        Errors err = new DirectFieldBindingResult(form, form.getClass().getSimpleName());
        formValidator.validate(form, err);
        if(err.hasErrors()) {
            log.debug("CurrencyTypeLOVForm has {} errors", err.getErrorCount());
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            log.debug("CurrencyTypeLOVForm error detail: {}", ec);
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        }
        log.debug("All attributes of CurrencyTypeLOVForm are valid");

        log.debug("Checking existence of CurrencyTypeLOVEntity with name: {}", form.getName());
        CurrencyTypeLOVEntity expectedEntity = form2EntityConverter.convert(form);
        if(repository.existsByName(expectedEntity.getName())) {
            log.debug("CurrencyTypeLOVEntity already exists with name: {}", expectedEntity.getName());
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_EXISTS,
                    new Object[]{ "name", form.getName() });
        }
        log.debug("No CurrencyTypeLOVEntity exists with name: {}", expectedEntity.getName());

        log.debug("Saving {}", expectedEntity);
        CurrencyTypeLOVEntity actualEntity = repository.save(expectedEntity);
        log.debug("Saved {}", actualEntity);

        if(actualEntity == null) {
            log.debug("Unable to create {}", expectedEntity);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "creation", "unable to persist CurrencyTypeLOVForm details" });
        }
        log.info("Created new CurrencyTypeLOVForm with id: {}", actualEntity.getId());
        return actualEntity.getId();
    }

    @Override
    @Transactional
    public void updateCurrencyTypeLOV(Long id, CurrencyTypeLOVForm form) throws TypeException {
        log.info("Updating CurrencyTypeLOVForm by id: {}", id);

        log.debug("Searching for CurrencyTypeLOVEntity with id: {}", id);
        Optional<CurrencyTypeLOVEntity> optActualEntity = repository.findById(id);
        if(optActualEntity.isEmpty()) {
            log.debug("No CurrencyTypeLOVEntity available with id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        log.debug("Found CurrencyTypeLOVEntity with id: {}", id);

        CurrencyTypeLOVEntity actualEntity = optActualEntity.get();
        if(!actualEntity.getActive()) {
            log.debug("CurrencyTypeLOVEntity is inactive with id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        log.debug("CurrencyTypeLOVEntity is active with id: {}", id);

        if(form == null) {
            log.debug("CurrencyTypeLOVForm is null");
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "not provided" });
        }
        log.debug("Form details : {}", form);

        log.debug("Validating provided attributes of CurrencyTypeLOVForm");
        Errors err = new DirectFieldBindingResult(form, form.getClass().getSimpleName());
        Boolean allEmpty = LOOSE_CURRENCY_TYPE_VALIDATOR.validateLoosely(form, err);
        if(err.hasErrors()) {
            log.debug("CurrencyTypeLOVForm has {} errors", err.getErrorCount());
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            log.debug("CurrencyTypeLOVForm error detail: {}", ec);
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        } else if (!allEmpty) {
            log.debug("All attributes of CurrencyTypeLOVForm are empty");
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "fields are empty" });
        }
        log.debug("All attributes of CurrencyTypeLOVForm are valid");

        Optional<CurrencyTypeLOVEntity> optExpectedEntity = COMPARE_AND_COPY_FORM.compareAndMap(actualEntity, form);
        if(optExpectedEntity.isEmpty()) {
            log.debug("All attributes of CurrencyTypeLOVForm are empty");
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "form", "fields are empty" });
        }
        log.debug("Successfully compared and copied attributes from CurrencyTypeLOVForm to CurrencyTypeLOVEntity");

        log.debug("Checking existence of CurrencyTypeLOVEntity with name: {}", form.getName());
        CurrencyTypeLOVEntity expectedEntity = optExpectedEntity.get();
        if(repository.existsByName(expectedEntity.getName())) {
            log.debug("CurrencyTypeLOVEntity already exists with name: {}", expectedEntity.getName());
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_EXISTS,
                    new Object[]{ "name", actualEntity.getName() });
        }
        log.debug("No CurrencyTypeLOVEntity exists with name: {}", expectedEntity.getName());

        COMPARE_AND_COPY_ENTITY.compareAndMap(expectedEntity, actualEntity);
        log.debug("Compared and copied attributes from CurrencyTypeLOVEntity to CurrencyTypeLOVForm");
        actualEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));

        log.debug("Updating: {}", actualEntity);
        actualEntity = repository.save(actualEntity);
        log.debug("Updated: {}", actualEntity);
        if(actualEntity == null) {
            log.debug("Unable to update {}", actualEntity);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "update", "unable to persist currency type LOV details" });
        }
        log.info("Updated existing CurrencyTypeLOVEntity with id: {} to version: {}", actualEntity.getId(), actualEntity.getVersion());
    }

    @Override
    @Transactional
    public void deleteCurrencyTypeLOV(Long id) throws TypeException {
        log.info("Soft deleting CurrencyTypeLOVEntity by id: {}", id);

        log.debug("Searching for CurrencyTypeLOVEntity with id: {}", id);
        Optional<CurrencyTypeLOVEntity> optEntity = repository.findById(id);
        if(optEntity.isEmpty()) {
            log.debug("No CurrencyTypeLOVEntity available with id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        log.debug("Found CurrencyTypeLOVEntity with id: {}", id);

        CurrencyTypeLOVEntity actualEntity = optEntity.get();
        if(!actualEntity.getActive()) {
            log.debug("CurrencyTypeLOVEntity is inactive with id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_INACTIVE, new Object[] { String.valueOf(id) });
        }
        log.debug("CurrencyTypeLOVEntity is active with id: {}", id);

        actualEntity.setActive(Boolean.FALSE);
        actualEntity.setModifiedOn(LocalDateTime.now(ZoneOffset.UTC));
        log.debug("Soft deleting: {}", actualEntity);
        CurrencyTypeLOVEntity expectedEntity = repository.save(actualEntity);
        log.debug("Soft deleted: {}", expectedEntity);
        if(expectedEntity == null) {
            log.debug("Unable to soft delete {}", actualEntity);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "deletion", "unable to soft delete current type LOV details with id:" + id });
        }

        log.info("Soft deleted existing CurrencyTypeLOVEntity with id: {}", actualEntity.getId());
    }

    @Override
    @Transactional
    public void applyPatchOnCurrencyTypeLOV(Long id, List<PatchOperationForm> patches) throws TypeException {
        log.info("Patching CurrencyTypeLOVEntity by id: {}", id);

        log.debug("Searching for CurrencyTypeLOVEntity with id: {}", id);
        Optional<CurrencyTypeLOVEntity> optActualEntity = repository.findById(id);
        if(optActualEntity.isEmpty()) {
            log.debug("No CurrencyTypeLOVEntity available with id: {}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_NOT_FOUND, new Object[] { "id", String.valueOf(id) });
        }
        log.debug("Found CurrencyTypeLOVEntity with id: {}", id);

        CurrencyTypeLOVEntity actualEntity = optActualEntity.get();
        if(patches == null || (patches != null && patches.isEmpty())) {
            log.debug("CurrencyTypeLOV patch list not provided");
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ATTRIBUTE_UNEXPECTED, new Object[]{ "patch", "not provided" });
        }
        log.debug("CurrencyTypeLOV patch list has {} items", patches.size());


        log.debug("Validating patch list items for CurrencyTypeLOV");
        try {
            toabBaseService.validatePatches(patches, TypeErrorCode.METADATA_EXISTS.getDomain() + ":" + LOVType.CURRENCY_TYPE.name());
            log.debug("All CurrencyTypeLOV patch list items are valid");
        } catch (TOABBaseException e) {
            log.debug("Some of the CurrencyTypeLOV patch item are invalid");
            throw new TypeException(LOVType.CURRENCY_TYPE, e.getError(), e.getParameters());
        }
        log.debug("Validated patch list items for CurrencyTypeLOV");


        log.debug("Patching list items to CurrencyTypeLOVDto");
        CurrencyTypeLOVDto patchedCurrencyTypeLOVForm = new CurrencyTypeLOVDto();
        try {
            log.debug("Preparing patch list items for CurrencyTypeLOV");
            JsonNode studentDtoTree = om.convertValue(patches, JsonNode.class);
            JsonPatch studentPatch = JsonPatch.fromJson(studentDtoTree);
            log.debug("Prepared patch list items for CurrencyTypeLOV");
            JsonNode blankCurrencyTypeLOVDtoTree = om.convertValue(new CurrencyTypeLOVDto(), JsonNode.class);
            JsonNode patchedCurrencyTypeLOVFormTree = studentPatch.apply(blankCurrencyTypeLOVDtoTree);
            log.debug("Applying patch list items to CurrencyTypeLOVDto");
            patchedCurrencyTypeLOVForm = om.treeToValue(patchedCurrencyTypeLOVFormTree, CurrencyTypeLOVDto.class);
            log.debug("Applied patch list items to CurrencyTypeLOVDto");
        } catch (IOException | JsonPatchException e) {
            log.debug("Failed to patch list items to CurrencyTypeLOVDto: {}", e);
            e.printStackTrace();
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE, new Object[]{ "patching", "internal error: " + e.getMessage() });
        }
        log.debug("Successfully to patch list items to CurrencyTypeLOVDto");

        log.debug("Validating patched CurrencyTypeLOVForm");
        Errors err = new DirectFieldBindingResult(patchedCurrencyTypeLOVForm, patchedCurrencyTypeLOVForm.getClass().getSimpleName());
        dtoValidator.validate(patchedCurrencyTypeLOVForm, err);
        if(err.hasErrors()) {
            log.debug("Patched CurrencyTypeLOVForm has {} errors", err.getErrorCount());
            TypeErrorCode ec = TypeErrorCode.valueOf(err.getFieldError().getCode());
            log.debug("Patched CurrencyTypeLOVForm error detail: {}", ec);
            throw new TypeException(LOVType.CURRENCY_TYPE, ec, new Object[] { err.getFieldError().getField(), err.getFieldError().getDefaultMessage() });
        }
        log.debug("All attributes of patched CurrencyTypeLOVForm are valid");

        log.debug("Comparatively copying patched attributes from CurrencyTypeLOVDto to CurrencyTypeLOVEntity");
        COMPARE_AND_COPY_PATCH.compareAndMap(actualEntity, patchedCurrencyTypeLOVForm);
        log.debug("Comparatively copied patched attributes from CurrencyTypeLOVDto to CurrencyTypeLOVEntity");

        log.debug("Saving patched CurrencyTypeLOVEntity: {}", actualEntity);
        actualEntity = repository.save(actualEntity);
        log.debug("Saved patched CurrencyTypeLOVEntity: {}", actualEntity);
        if(actualEntity == null) {
            log.debug("Unable to patch delete CurrencyTypeLOVEntity with id:{}", id);
            throw new TypeException(LOVType.CURRENCY_TYPE, TypeErrorCode.METADATA_ACTION_FAILURE,
                    new Object[]{ "patching", "unable to patch currency type LOV details with id:" + id });
        }
        log.info("Patched CurrencyTypeLOVEntity with id:{}", id);
    }
}