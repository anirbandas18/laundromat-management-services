package com.teenthofabud.laundromat.manager.type.converter.entity2vo;

import com.teenthofabud.laundromat.manager.type.model.entity.LogisticServiceLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.vo.LogisticServiceLOVVo;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class LogisticServiceLOVEntity2VoConverter implements Converter<LogisticServiceLOVEntity, LogisticServiceLOVVo> {
    @Override
    public LogisticServiceLOVVo convert(LogisticServiceLOVEntity entity) {
        LogisticServiceLOVVo vo = new LogisticServiceLOVVo();
        vo.setName(entity.getName());
        vo.setDescription(entity.getDescription());
        vo.setId(entity.getId());
        vo.setActive(entity.getActive());
        return vo;
    }
}
