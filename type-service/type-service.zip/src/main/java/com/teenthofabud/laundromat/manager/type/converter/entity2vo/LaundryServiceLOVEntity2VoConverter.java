package com.teenthofabud.laundromat.manager.type.converter.entity2vo;

import com.teenthofabud.laundromat.manager.type.model.entity.LaundryServiceLOVEntity;
import com.teenthofabud.laundromat.manager.type.model.vo.LaundryServiceLOVVo;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

@Component
public class LaundryServiceLOVEntity2VoConverter implements Converter<LaundryServiceLOVEntity, LaundryServiceLOVVo> {
    @Override
    public LaundryServiceLOVVo convert(LaundryServiceLOVEntity entity) {
        LaundryServiceLOVVo vo = new LaundryServiceLOVVo();
        vo.setName(entity.getName());
        vo.setDescription(entity.getDescription());
        vo.setId(entity.getId());
        vo.setActive(entity.getActive());
        return vo;
    }
}
